## spliceQTL 0.0.0 (2018-06-12)

* Added functions