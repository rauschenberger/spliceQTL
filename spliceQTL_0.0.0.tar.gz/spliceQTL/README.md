
<!-- Modify xxx.Rmd, not xxx.md! -->

[![Travis-CI Build
Status](https://travis-ci.org/rauschenberger/spliceQTL.svg)](https://travis-ci.org/rauschenberger/spliceQTL)
[![AppVeyor build
status](https://ci.appveyor.com/api/projects/status/github/rauschenberger/spliceQTL?svg=true)](https://ci.appveyor.com/project/rauschenberger/spliceQTL)

``` r
#install.packages("devtools")
devtools::install_github("rauschenberger/spliceQTL")
```
